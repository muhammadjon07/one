import React from "react";

import Header from "./top/index";
import Body from "./twice/index";

const index = () => {
  return (
    <div>
      <Header />
      <Body />
    </div>
  );
};

export default index;
